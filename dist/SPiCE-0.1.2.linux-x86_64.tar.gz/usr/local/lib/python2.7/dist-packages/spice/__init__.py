'''This is the Sequence-based Protein Classification and Exploration (SPiCE)
module.

.. moduleauthor:: Bastiaan van den Berg <b.a.vandenberg@gmail.com>

'''
