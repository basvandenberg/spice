'''This is the Sequence-based Protein Classification (SPiCa) module.

.. moduleauthor:: Bastiaan van den Berg <b.a.vandenberg@gmail.com>

'''
